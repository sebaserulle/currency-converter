# Currency Converter (USD to DOP)

A simple React + Node app that converts USD to Dominican Pesos using real-time data from CurrencyLayer.

## Folders
- `client/` → React frontend
- `server/` → Express backend with secure API key handling
